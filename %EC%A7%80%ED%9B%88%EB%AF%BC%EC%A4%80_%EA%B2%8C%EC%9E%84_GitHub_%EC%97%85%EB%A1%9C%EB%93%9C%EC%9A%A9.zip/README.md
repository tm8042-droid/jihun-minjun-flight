# 지훈 & 민준 비행 게임

브라우저에서 실행하는 HTML 게임입니다.

## 로컬 실행

`index.html` 파일을 브라우저에서 열면 됩니다.

## GitHub에 업로드하기

1. GitHub에서 새 저장소(repository)를 만듭니다.
2. 이 폴더의 `index.html`과 `README.md`를 저장소 루트에 업로드합니다.
3. 웹으로 공개해 플레이하려면 저장소의 **Settings → Pages**로 이동합니다.
4. **Deploy from a branch**를 선택하고 `main` 브랜치 및 `/(root)` 폴더를 지정한 뒤 저장합니다.
5. 배포가 완료되면 GitHub Pages가 표시하는 사이트 주소로 접속합니다.

> 참고: GitHub에 업로드하는 것과 GitHub Pages로 웹사이트를 공개하는 것은 별도 단계입니다.
